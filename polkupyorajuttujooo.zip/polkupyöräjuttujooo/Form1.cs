using System.IO;
using System.Text;

namespace polkupyöräjuttujooo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        
        private void button1_Click(object sender, EventArgs e)
        {
            string puhelin = textBox1.Text;
            string runko = textBox2.Text;
            string omistaja = textBox3.Text;
            string merkki = textBox4.Text;
            string väri = textBox5.Text;


            string tiedosto = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "register.txt");




            if (textBox1.Text.Length == 0 || textBox2.Text.Length == 0 || textBox3.Text.Length == 0 || textBox4.Text.Length == 0 || textBox5.Text.Length == 0)
            {
                MessageBox.Show("Täytä kaikki kentät");
            }
            else
            {

               

                 TextWriter teksti = new StreamWriter(tiedosto, true);
                 teksti.WriteLine("----------");
                 teksti.WriteLine("Omistaja = " + omistaja);
                 teksti.WriteLine("Puhelin = " + puhelin);
                 teksti.WriteLine("Runkonumero = " + runko);
                 teksti.WriteLine("Merkki = " + merkki);
                 teksti.WriteLine("Väri = " + väri);
                 teksti.Close(); 
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string tiedosto = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "register.txt");
            TextWriter tsw = new StreamWriter(tiedosto);
            tsw.Write("");
            tsw.Close();
            textBox6.Text = string.Empty;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
            textBox3.Text = string.Empty;
            textBox4.Text = string.Empty;
            textBox5.Text = string.Empty;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string tiedosto = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "register.txt");
           
            var str = File.ReadAllText(tiedosto);
            textBox6.Text = str;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string tiedosto = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "register.txt");
        

            
            string[] lines = File.ReadAllLines(tiedosto);

           
            if (lines.Length > 0)
            {
                
                List<string> updatedLines = new List<string>(lines);

               
                int lastIndex = updatedLines.FindLastIndex(line => line.Equals("----------"));
                if (lastIndex >= 0)
                {
                    updatedLines.RemoveRange(lastIndex, updatedLines.Count - lastIndex);
                }

               
                File.WriteAllLines(tiedosto, updatedLines);

               
                MessageBox.Show("Last log entry removed.", "Log Removed");
            }
            else
            {
                MessageBox.Show("No log entries to remove.", "No Logs");
            }
        }
    }
}