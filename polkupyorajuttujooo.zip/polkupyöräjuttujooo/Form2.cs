﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace polkupyöräjuttujooo
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {



            int record = 1;
            foreach (string s in File.ReadAllLines("Users.txt"))
            {
                if (s.Split(",")[0] == textBox1.Text)
                {
                    bool verify = BCrypt.Net.BCrypt.Verify(textBox2.Text, s.Split(",")[1]);
                    if (verify)
                    {

                        this.Hide();
                        Form frm2 = new Form1();
                        frm2.ShowDialog();
                    }
                }
                record = record + 1;
            }



        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form frm2 = new Form3();
            frm2.ShowDialog();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.PasswordChar = '●';
        }
    }
}
