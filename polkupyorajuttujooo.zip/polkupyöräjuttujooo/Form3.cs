﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace polkupyöräjuttujooo
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
           
            string hash = BCrypt.Net.BCrypt.HashPassword(textBox2.Text);
            if (File.Exists("Users.txt"))
            {
                File.AppendAllText("Users.txt", "\n" + textBox1.Text + "," +hash);

            }
            else
            {
                File.Create("Users.txt").Dispose();
                File.WriteAllText("Users.txt", textBox1 + "," + hash);
            }
            MessageBox.Show("Käyttäjä tallennettu");

            this.Hide();
            Form frm2 = new Form2();
            frm2.ShowDialog();

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.PasswordChar = '●';
        }
    }
}
